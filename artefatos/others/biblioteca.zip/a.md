Feedback=

- A IDE não possui feedback claro sobre as ações do sistema (Exemplo os botões para cadastrar quando deu erro).
- Não foi possível testar analisador sintático pois não tinha a funcionalidade de blocos integrada.

Argumento:
	Argumentos o segundo argumento feedback não está de acordo com a entrega realizada pelo o grupo. Quando o usuário insere um código (cadastrar consulta), todas as etapas do compilador implementadas até o momento fornecem feedbacks específicos dependendo de cada etapa. O retorno para um erro léxico aparece com um fundo amarelo, indicando onde e qual foi o erro. Para um erro sintático, a cor muda para vermelho. Se o código inserido estiver correto, o fundo fica verde, indicando que tudo está certo. (Tudo o que foi escrito foi demostrado na apresentação da 3° sprint)

    O segundo feedback também está incorreto. Para a sprint passada, o diagrama em blocos não precisava estar integrado com o analisador sintático. A tarefa era apenas implementar a lógica dos blocos, de modo que retornassem uma estrutura de código(o que esta sendo feito), mas não havia a necessidade de integração com o analisador sintático nessa sprint.
